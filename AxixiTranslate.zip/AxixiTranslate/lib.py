import os, re, json, hashlib
import xml.etree.ElementTree as ET

HAN = re.compile(r'[\u4e00-\u9fff]')
JAVA_SKIP_FILES = {'CreditsActivity.java', 'StreamSessionLogger.java'}
JAVA_SKIP_LINE = re.compile(r'LimeLog|Log\.[dievwtf]\(|logSession|writeRawDirect|printStackTrace|System\.out|\.equals\(|equalsIgnoreCase|\bcase\s|static\s+final|@\w+\(')

def java_tokens(src):
    """Yield (start, end, raw_inner) for every string literal that is not inside a comment."""
    i = 0; n = len(src); out = []
    while i < n:
        c = src[i]
        if src.startswith('//', i):
            j = src.find('\n', i); i = n if j < 0 else j
        elif src.startswith('/*', i):
            j = src.find('*/', i + 2); i = n if j < 0 else j + 2
        elif c == '"':
            j = i + 1
            while j < n and src[j] != '"':
                j += 2 if src[j] == '\\' else 1
            out.append((i, j + 1, src[i + 1:j])); i = j + 1
        elif c == "'":
            j = i + 1
            while j < n and src[j] != "'":
                j += 2 if src[j] == '\\' else 1
            i = j + 1
        else:
            i += 1
    return out

def java_unescape(s):
    return (s.replace('\\n', '\n').replace('\\t', '\t').replace('\\"', '"').replace("\\'", "'").replace('\\\\', '\\'))

def java_escape(s):
    return s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\t', '\\t')

def line_of(src, pos):
    a = src.rfind('\n', 0, pos) + 1
    b = src.find('\n', pos); b = len(src) if b < 0 else b
    return src[a:b]

def xml_unescape_attr(s):
    return (s.replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('&apos;', "'").replace('&amp;', '&'))

def android_text_unescape(s):
    # value as written inside <string> (already XML-decoded) -> display text
    return re.sub(r'\\(.)', lambda m: {'n': '\n', 't': '\t'}.get(m.group(1), m.group(1)), s, flags=re.S)

def android_text_escape(s):
    s = s.replace('\\', '\\\\').replace("'", "\\'").replace('"', '\\"').replace('\n', '\\n').replace('\t', '\\t')
    if s.startswith('@') or s.startswith('?'):
        s = '\\' + s
    return s

def xml_escape(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def key_for(text):
    return 'ax_' + hashlib.md5(text.encode('utf-8')).hexdigest()[:8]
