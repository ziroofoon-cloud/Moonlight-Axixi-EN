#!/usr/bin/env python3
"""Run AFTER apply.py:  python3 apply_extra.py <path-to-moonlight-android>
Fixes what apply.py skips on purpose: comparison literals ("待触发"), names coming from assets/*.json,
and the Chinese accessibility descriptions of the extension keyboard."""
import sys, os, re
ROOT = sys.argv[1].rstrip('/'); HERE = os.path.dirname(os.path.abspath(__file__))
J = ROOT + '/app/src/main/java/'; RES = ROOT + '/app/src/main/res/'
def rd(p):
    with open(p, encoding='utf-8', newline='') as f: return f.read()
def wr(p, t):
    with open(p, 'w', encoding='utf-8', newline='') as f: f.write(t)
def esc(s): return s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
rows = []
for l in open(HERE + '/extra.tsv', encoding='utf-8'):
    l = l.rstrip('\n')
    if l and not l.startswith('#'):
        p = l.split('\t')
        if len(p) >= 3: rows.append(p[:3])
# 1) TrData: add rows to part0 (skip those already present)
tp = J + 'com/limelight/utils/TrData.java'; t = rd(tp)
add = ''.join('            {"%s", "%s", "%s"},\n' % (esc(a), esc(b), esc(c)) for a, b, c in rows if '{"%s",' % esc(a) not in t)
m = re.search(r'static String\[\]\[\] part0\(\) \{\s*return new String\[\]\[\]\{\r?\n', t)
if add and m: t = t[:m.end()] + add + t[m.end():]; wr(tp, t)
T = 'com.limelight.utils.Tr.t("待触发")'
# 2) "待触发" comparisons / returns
for f in ('Game.java', 'binding/input/ControllerHandler.java'):
    p = J + 'com/limelight/' + f; s = rd(p)
    s2 = re.sub(r'(?<!Tr\.t\()"待触发"(?!\s*\))', T, s)
    s2 = s2.replace('Tr.t(' + T + ')', T)
    if s2 != s: wr(p, s2)
# 3) names that come from assets/config/*.json
p = J + 'com/limelight/binding/input/virtual_controller/keyboard/KeyBoardControllerConfigurationLoader.java'
s = rd(p); s2 = s.replace('obj.optString("name")', 'com.limelight.utils.Tr.t(obj.optString("name"))')
if s2 != s: wr(p, s2)
# 4) extension keyboard accessibility texts (were Chinese in every language)
p = RES + 'values/extension_ime_keyboard_styles.xml'; s = rd(p)
for k, v in (('CMD，可锁定', 'CMD (lockable)'), ('CTRL，可锁定', 'CTRL (lockable)'), ('ALT，可锁定', 'ALT (lockable)')):
    s = s.replace(k, v)
wr(p, s)
print('extra done; remaining Han in extension styles:', len(re.findall(r'[\u4e00-\u9fff]', s)))
