#!/usr/bin/env python3
"""Step 3 - floating bubble (CrownPad idea) on top of Axixi's own controls.
usage: python3 apply_bubble.py <path-to-moonlight-android>   (run after apply.py and apply_extra.py)

* new: HeadlessSession (input-only connection that joins the running PC session), BubbleService (bubble,
  quick panel, control layer), BubbleActivity (setup screen, 2nd launcher icon), InputBridge, OscSink
* changed: KeyBoardController / KeyBoardLayoutController / loader now talk to InputBridge instead of Game.instance
  and no longer need an Activity (so they can live in an overlay window); NvConnection gets setJoinExisting(true);
  Tr gets lang(); manifest gets the overlay permissions, service and activity.
Every edit asserts that its anchor exists, so a changed upstream fails loudly instead of silently."""
import os, re, sys, shutil
ROOT = sys.argv[1].rstrip('/'); HERE = os.path.dirname(os.path.abspath(__file__))
J = ROOT + '/app/src/main/java/com/limelight/'; RES = ROOT + '/app/src/main/res/'
VC = J + 'binding/input/virtual_controller/keyboard/'
IB = 'com.limelight.binding.input.InputBridge'

def rd(p):
    with open(p, encoding='utf-8', newline='') as f: t = f.read()
    return t.replace('\r\n', '\n'), '\r\n' in t
def wr(p, t, crlf):
    if crlf: t = t.replace('\n', '\r\n')
    with open(p, 'w', encoding='utf-8', newline='') as f: f.write(t)
def must(t, old, new, count=1, what=''):
    n = t.count(old)
    if n < 1 or (count and n != count):
        sys.exit('ANCHOR PROBLEM (%s): expected %s, found %d of %r' % (what, count or '>=1', n, old[:70]))
    return t.replace(old, new)

# --- 1) new files
dst = J + 'overlay/'; os.makedirs(dst, exist_ok=True)
for f in ('HeadlessSession', 'BubbleService', 'BubbleActivity', 'BubbleKit', 'BubbleText'):
    shutil.copy(HERE + '/bubble/%s.java' % f, dst + f + '.java')
for f in ('InputBridge', 'OscSink'):
    shutil.copy(HERE + '/bubble/%s.java' % f, J + 'binding/input/%s.java' % f)
os.makedirs(RES + 'drawable', exist_ok=True)
shutil.copy(HERE + '/bubble/ic_bubble_notif.xml', RES + 'drawable/ic_bubble_notif.xml')

# --- 2) ControllerHandler implements OscSink
p = J + 'binding/input/ControllerHandler.java'; t, c = rd(p)
if 'OscSink' not in t:
    t = must(t, 'implements InputManager.InputDeviceListener, UsbDriverListener {', 'implements InputManager.InputDeviceListener, UsbDriverListener, OscSink {', what='ControllerHandler')
    wr(p, t, c)

# --- 3) KeyBoardController
p = VC + 'KeyBoardController.java'; t, c = rd(p)
if 'OscSink' not in t:
    t = must(t, 'private final ControllerHandler controllerHandler;', 'private final com.limelight.binding.input.OscSink controllerHandler;', what='kbc field')
    t = must(t, 'public KeyBoardController(final ControllerHandler controllerHandler, FrameLayout layout, final Activity context,',
                'public KeyBoardController(final com.limelight.binding.input.OscSink controllerHandler, FrameLayout layout, final Context context,', what='kbc ctor')
    t = must(t, 'private final Activity context;', 'private final Context context;', what='kbc ctx')
    t = must(t, 'context.getWindowManager().getCurrentWindowMetrics()',
                '((android.view.WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getCurrentWindowMetrics()', count=2, what='wm')
    t = must(t, 'fragment.show(context.getFragmentManager());',
                'if (activityFragmentManager() == null) { Toast.makeText(context, com.limelight.overlay.BubbleText.openEditorHint(), Toast.LENGTH_LONG).show(); return; }\n'
                '                fragment.show(activityFragmentManager());', count=2, what='frag')
    t = must(t, '    public boolean isLandscape(Context context) {',
                '''    /** The fragment manager of the hosting Activity, or null when the controls live in an overlay window. */
    private android.app.FragmentManager activityFragmentManager() {
        Context c = context;
        while (c instanceof android.content.ContextWrapper) {
            if (c instanceof Activity) return ((Activity) c).getFragmentManager();
            c = ((android.content.ContextWrapper) c).getBaseContext();
        }
        return null;
    }

    public boolean isLandscape(Context context) {''', what='helper')
    t = must(t, 'if (Game.instance == null || !Game.instance.connected) {', 'if (!%s.isConnected()) {' % IB, count=2, what='connected')
    t = t.replace('Game.instance.mouseButtonEvent(', IB + '.mouseButtonEvent(').replace('Game.instance.keyboardEvent(', IB + '.keyboardEvent(').replace('Game.instance.mouseMove(', IB + '.mouseMove(')
    a = t.index('switch (value){'); b = t.index('            return;\n        }\n        for (int i = 0; i < keys.length')
    t = t[:a] + ('switch (value){\n                case 7:\n                    %s.toggleSoftKeyboard();\n                    break;\n'
                 '                case 8: case 9: case 10: case 11: case 12: case 13:\n                    %s.special(value);\n                    break;\n'
                 '                default:\n                    break;\n            }\n') % (IB, IB) + t[b:]
    assert 'Game.instance' not in t, 'KeyBoardController still uses Game.instance'
    wr(p, t, c)

# --- 4) KeyBoardLayoutController
p = VC + 'KeyBoardLayoutController.java'; t, c = rd(p)
if 'OscSink' not in t:
    t = must(t, 'private final ControllerHandler controllerHandler;', 'private final com.limelight.binding.input.OscSink controllerHandler;', what='kbl field')
    t = must(t, 'public KeyBoardLayoutController(final ControllerHandler controllerHandler,', 'public KeyBoardLayoutController(final com.limelight.binding.input.OscSink controllerHandler,', what='kbl ctor')
    t, n = re.subn(r'if \(!Game\.instance\.hasWindowFocus\(\)\) \{\s*new Handler\(\)\.postDelayed\(\(\) -> Game\.instance\.toggleKeyboard\(\),10\);\s*return;\s*\}\s*Game\.instance\.toggleKeyboard\(\);',
                   IB + '.toggleSoftKeyboard();', t)
    assert n == 1, 'soft keyboard block'
    t = must(t, 'if (Game.instance == null || !Game.instance.connected) {', 'if (!%s.isConnected()) {' % IB, what='kbl connected')
    t = t.replace('Game.instance.showGameMenu()', IB + '.special(13)')
    for m in ('mouseMove', 'mouseHighResScroll', 'mouseButtonEvent', 'keyboardEvent'):
        t = t.replace('Game.instance.%s(' % m, '%s.%s(' % (IB, m))
    assert 'Game.instance' not in t.replace('//', '\n//').split('\n//')[0] or True
    left = [l for l in t.split('\n') if 'Game.instance' in l and not l.strip().startswith('//')]
    assert not left, 'KeyBoardLayoutController still uses Game.instance: %r' % left[:2]
    wr(p, t, c)

# --- 5) loader (mouse wheel repeater)
p = VC + 'KeyBoardControllerConfigurationLoader.java'; t, c = rd(p)
if 'Game.instance.mouseHighResScroll(' in t:
    t = t.replace('Game.instance.mouseHighResScroll(', IB + '.mouseHighResScroll(')
    wr(p, t, c)

# --- 6) NvConnection: join the running session instead of quitting it
p = J + 'nvstream/NvConnection.java'; t, c = rd(p)
if 'joinExisting' not in t:
    t = must(t, '    private final boolean isMonkey;', '    private final boolean isMonkey;\n    private boolean joinExisting = false;\n\n    /** Resume whatever is running on the host instead of quitting it (used by the floating bubble). */\n    public void setJoinExisting(boolean join) { this.joinExisting = join; }', what='nv field')
    t = must(t, 'if (h.getCurrentGame(serverInfo) == app.getAppId()) {', 'if (joinExisting || h.getCurrentGame(serverInfo) == app.getAppId()) {', what='nv cond')
    t = must(t, 'h.launchApp(context, "resume", app.getAppId(), context.negotiatedHdr)', 'h.launchApp(context, "resume", joinExisting ? h.getCurrentGame(serverInfo) : app.getAppId(), context.negotiatedHdr)', what='nv resume')
    wr(p, t, c)

# --- 7) Tr.lang()  (+ the template inside apply.py so a fresh run produces it too)
LANG = '''    /** Language code in use ("fa", "en", "zh", ...). */
    public static String lang() {
        return forced != null ? forced : Locale.getDefault().getLanguage();
    }

'''
p = J + 'utils/Tr.java'; t, c = rd(p)
if 'String lang()' not in t:
    t = must(t, '    public static String t(String zh) {', LANG + '    public static String t(String zh) {', what='Tr')
    wr(p, t, c)

# --- 8) strings
for d, name in (('values', 'Axixi Bubble'), ('values-fa', 'حباب Axixi'), ('values-zh-rCN', '阿西西悬浮球'), ('values-zh-rTW', '阿西西懸浮球')):
    os.makedirs(RES + d, exist_ok=True)
    with open(RES + d + '/strings_bubble.xml', 'w', encoding='utf-8') as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="bubble_app_name">%s</string>\n</resources>\n' % name)

# --- 9) manifest
p = ROOT + '/app/src/main/AndroidManifest.xml'; t, c = rd(p)
if 'BubbleService' not in t:
    perms = ''
    for perm in ('SYSTEM_ALERT_WINDOW', 'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_SPECIAL_USE', 'POST_NOTIFICATIONS'):
        if 'android.permission.%s"' % perm not in t:
            perms += '    <uses-permission android:name="android.permission.%s" />\n' % perm
    m = re.search(r'<manifest[^>]*>\n', t)
    t = t[:m.end()] + perms + t[m.end():]
    comp = '''        <!-- Floating bubble (CrownPad idea) -->
        <activity
            android:name="com.limelight.overlay.BubbleActivity"
            android:exported="true"
            android:label="@string/bubble_app_name"
            android:icon="@drawable/ic_bubble_notif"
            android:theme="@android:style/Theme.DeviceDefault.NoActionBar"
            android:taskAffinity="com.limelight.bubble"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <service
            android:name="com.limelight.overlay.BubbleService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="Floating on-screen control layer shown over other apps" />
        </service>
'''
    t = must(t, '</application>', comp + '    </application>', what='manifest')
    wr(p, t, c)
print('bubble applied')
