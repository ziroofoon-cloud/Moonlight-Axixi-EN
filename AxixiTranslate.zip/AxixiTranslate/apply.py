#!/usr/bin/env python3
"""Translates Moonlight-Axixi (Chinese) into English (default) + Persian.

usage: python3 apply.py <path-to-moonlight-android>
Reads zh.tsv (zh <TAB> en <TAB> fa) and en_fa.tsv (resource key <TAB> fa) next to this script.
Strings that are not in the dictionaries are left untouched, so a newer upstream version still builds.
"""
import sys, os, re, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import *

ROOT = sys.argv[1].rstrip('/')
HERE = os.path.dirname(os.path.abspath(__file__))
RES = ROOT + '/app/src/main/res/'
JAVA = ROOT + '/app/src/main/java'
FMT = re.compile(r'%(?:\d+\$)?[-#+0,(]*\d*(?:\.\d+)?[a-zA-Z%]')

def unesc(s): return s.replace('\\n', '\n').replace('\\t', '\t')

D = {}  # zh -> (en, fa)
for line in open(HERE + '/zh.tsv', encoding='utf-8'):
    line = line.rstrip('\n')
    if not line or line.startswith('#'): continue
    p = line.split('\t')
    if len(p) < 3: continue
    D[unesc(p[0])] = (unesc(p[1]), unesc(p[2]))
EF = {}  # resource key -> fa
for line in open(HERE + '/en_fa.tsv', encoding='utf-8'):
    line = line.rstrip('\n')
    if not line or line.startswith('#'): continue
    p = line.split('\t')
    if len(p) >= 2 and p[1].strip(): EF[p[0]] = unesc(p[1])

stats = collections.Counter()
warn = []

def fmt_ok(src, dst):
    return sorted(FMT.findall(src)) == sorted(FMT.findall(dst))

def tr(zh, idx):
    """idx 0=en 1=fa; falls back to None when missing or when format args differ."""
    v = D.get(zh)
    if not v or not v[idx].strip(): return None
    if not fmt_ok(zh, v[idx]):
        warn.append('format mismatch: %r -> %r' % (zh[:40], v[idx][:40])); return None
    return v[idx]

def rd(p):
    with open(p, encoding='utf-8', newline='') as f: return f.read()
def wr(p, t):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'w', encoding='utf-8', newline='') as f: f.write(t)

def existing_keys(p):
    if not os.path.exists(p): return set()
    return set(re.findall(r'<string\s+name="([^"]+)"', rd(p)))

def res_xml(entries):
    out = ['<?xml version="1.0" encoding="utf-8"?>', '<resources>']
    for e in entries:
        k, v = e[0], e[1]
        pre, post = (e[2], e[3]) if len(e) > 2 else ('', '')
        out.append('    <string name="%s">%s%s%s</string>' % (k, pre, xml_escape(android_text_escape(v)), post))
    out.append('</resources>')
    return '\n'.join(out) + '\n'

STR_RE = re.compile(r'(<string\b([^>]*?)>)(.*?)(</string>)', re.S)
zh_extra = []   # (key, original zh) for chinese locales
fa_strings = [] # (key, fa)
en_default_keys = set()

# ---------- 1) default string resources ----------
for fname in ['strings.xml', 'strings_settings_panel.xml']:
    p = RES + 'values/' + fname
    if not os.path.exists(p): continue
    t = rd(p)
    def sub(m):
        attrs = m.group(2); raw = m.group(3).replace('\r\n', '\n')
        nm = re.search(r'name="([^"]+)"', attrs)
        if not nm or 'translatable="false"' in attrs: return m.group(0)
        pre = post = ''
        um = re.fullmatch(r'<u>(.*)</u>', raw, re.S)
        if um: pre, post, raw = '<u>', '</u>', um.group(1)
        if '<' in raw: return m.group(0)
        key = nm.group(1)
        txt = android_text_unescape(xml_unescape_attr(raw))
        if HAN.search(txt):
            en = tr(txt, 0); fa = tr(txt, 1)
            if en is None: stats['res_untranslated'] += 1; return m.group(0)
            zh_extra.append((key, txt, pre, post))
            if fa: fa_strings.append((key, fa, pre, post)); stats['res_fa'] += 1
            stats['res_en'] += 1
            return m.group(1) + pre + xml_escape(android_text_escape(en)) + post + m.group(4)
        if key in EF:
            f = EF[key]
            if fmt_ok(txt, f): fa_strings.append((key, f, '', '')); stats['res_fa_en'] += 1
            else: warn.append('format mismatch key ' + key)
        return m.group(0)
    wr(p, STR_RE.sub(sub, t))

# ---------- 2) arrays ----------
p = RES + 'values/arrays.xml'
t = rd(p)
zh_arrays = []; fa_arrays = []
ARR_RE = re.compile(r'(<string-array\b([^>]*?)>)(.*?)(</string-array>)', re.S)
ITEM_RE = re.compile(r'(<item\b[^>]*>)(.*?)(</item>)', re.S)
def sub_arr(m):
    name = re.search(r'name="([^"]+)"', m.group(2)).group(1)
    if 'translatable="false"' in m.group(2): return m.group(0)
    body = m.group(3)
    items = ITEM_RE.findall(body)
    texts = [android_text_unescape(xml_unescape_attr(i[1].replace('\r\n', '\n'))) for i in items]
    if not any(HAN.search(x) for x in texts): return m.group(0)
    en_items = []; fa_items = []; ok = True
    for x in texts:
        if HAN.search(x):
            e = tr(x, 0); f = tr(x, 1)
            if e is None: ok = False; break
            en_items.append(e); fa_items.append(f or e)
        else:
            en_items.append(x); fa_items.append(x)
    if not ok: stats['arr_untranslated'] += 1; return m.group(0)
    def build(vals):
        return ''.join('\n        <item>%s</item>' % xml_escape(android_text_escape(v)) for v in vals) + '\n    '
    zh_arrays.append((name, texts)); fa_arrays.append((name, fa_items)); stats['arr'] += 1
    return m.group(1) + build(en_items) + m.group(4)
wr(p, ARR_RE.sub(sub_arr, t))
def arrays_xml(arrs):
    o = ['<?xml version="1.0" encoding="utf-8"?>', '<resources>']
    for n, vals in arrs:
        o.append('    <string-array name="%s">' % n)
        for v in vals: o.append('        <item>%s</item>' % xml_escape(android_text_escape(v)))
        o.append('    </string-array>')
    o.append('</resources>')
    return '\n'.join(o) + '\n'

# ---------- 3) hard-coded attributes in layouts / preferences ----------
ATTRS = ('android:text', 'android:hint', 'android:title', 'android:summary', 'android:dialogTitle', 'android:dialogMessage',
         'android:contentDescription', 'android:label', 'android:description', 'android:positiveButtonText',
         'android:negativeButtonText', 'android:tooltipText', 'android:prompt')
attr_re = re.compile(r'(\s)([\w:]+)="([^"]*[\u4e00-\u9fff][^"]*)"')
ax = collections.OrderedDict()  # key -> zh
for d in sorted(os.listdir(RES)):
    if not (d.startswith('layout') or d in ('xml', 'menu')): continue
    for f in sorted(os.listdir(RES + d)):
        if not f.endswith('.xml'): continue
        p = RES + d + '/' + f
        t = rd(p)
        def sub_attr(m):
            if m.group(2) not in ATTRS: return m.group(0)
            txt = android_text_unescape(xml_unescape_attr(m.group(3)))
            if tr(txt, 0) is None: stats['attr_untranslated'] += 1; return m.group(0)
            k = key_for(txt); ax[k] = txt; stats['attr'] += 1
            return '%s%s="@string/%s"' % (m.group(1), m.group(2), k)
        t2 = attr_re.sub(sub_attr, t)
        if t2 != t: wr(p, t2)

# ---------- 4) write locale files ----------
zhdir_keys = {}
for loc in ('values-zh-rCN', 'values-zh-rTW'):
    have = existing_keys(RES + loc + '/strings.xml')
    extra = [e for e in zh_extra if e[0] not in have]
    zhdir_keys[loc] = extra
    ents = extra + [(k, v) for k, v in ax.items()]
    if ents: wr(RES + loc + '/strings_ax.xml', res_xml(ents))
    if zh_arrays: wr(RES + loc + '/arrays.xml', arrays_xml(zh_arrays))
if ax:
    wr(RES + 'values/strings_ax.xml', res_xml([(k, tr(v, 0)) for k, v in ax.items()]))
    wr(RES + 'values-fa/strings_ax.xml', res_xml([(k, tr(v, 1) or tr(v, 0)) for k, v in ax.items()]))
# values-fa/strings.xml (replaces the empty upstream file)
seen = set(); fa_u = []
for e in fa_strings:
    if e[0] not in seen: seen.add(e[0]); fa_u.append(e)
wr(RES + 'values-fa/strings.xml', res_xml(fa_u))
if fa_arrays: wr(RES + 'values-fa/arrays.xml', arrays_xml(fa_arrays))

# ---------- 5) java literals -> Tr.t("...") ----------
banned = set()
for root, _, fs in os.walk(JAVA):
    for f in fs:
        if not f.endswith('.java'): continue
        src = rd(os.path.join(root, f))
        for a, b, inner in java_tokens(src):
            if HAN.search(inner) and re.search(r'\.equals\(|equalsIgnoreCase|\bcase\s|\bswitch\b', line_of(src, a)):
                banned.add(java_unescape(inner))
java_texts = collections.OrderedDict()
for root, _, fs in os.walk(JAVA):
    for f in sorted(fs):
        if not f.endswith('.java') or f in JAVA_SKIP_FILES: continue
        p = os.path.join(root, f)
        src = rd(p)
        edits = []
        for a, b, inner in java_tokens(src):
            if not HAN.search(inner): continue
            if JAVA_SKIP_LINE.search(line_of(src, a)): continue
            txt = java_unescape(inner)
            if txt in banned: stats['java_banned'] += 1; continue
            if tr(txt, 0) is None: stats['java_untranslated'] += 1; continue
            edits.append((a, b, inner)); java_texts[txt] = 1
        if edits:
            for a, b, inner in reversed(edits):
                src = src[:a] + 'com.limelight.utils.Tr.t("' + inner + '")' + src[b:]
            wr(p, src); stats['java'] += len(edits)

# Tr.java + TrData.java
chunks = []
items = list(java_texts.keys())
CH = 40
body = []
for ci in range(0, len(items), CH):
    part = items[ci:ci + CH]
    lines = ''.join('            {"%s", "%s", "%s"},\n' % (java_escape(z), java_escape(tr(z, 0)), java_escape(tr(z, 1) or tr(z, 0))) for z in part)
    body.append('    static String[][] part%d() {\n        return new String[][]{\n%s        };\n    }\n' % (ci // CH, lines))
n_parts = len(body)
data = 'package com.limelight.utils;\n\n/** Generated by apply.py: [zh, en, fa] triples. */\nfinal class TrData {\n    private TrData() {}\n\n    static String[][][] all() {\n        return new String[][][]{' + ', '.join('part%d()' % i for i in range(n_parts)) + '};\n    }\n\n' + '\n'.join(body) + '}\n'
wr(JAVA + '/com/limelight/utils/TrData.java', data)
wr(JAVA + '/com/limelight/utils/Tr.java', '''package com.limelight.utils;

import java.util.HashMap;
import java.util.Locale;

/** Runtime translation for strings that are hard-coded in Java code (Chinese -> English / Persian). */
public final class Tr {
    private static HashMap<String, String[]> map;
    private static volatile String forced;

    private Tr() {}

    /** Called with the language chosen inside the app ("default", "fa", "zh-CN", ...). */
    public static void setLang(String tag) {
        if (tag == null || tag.equals("default")) {
            forced = null;
            return;
        }
        int i = tag.indexOf('-');
        forced = i > 0 ? tag.substring(0, i) : tag;
    }

    private static synchronized HashMap<String, String[]> map() {
        if (map == null) {
            HashMap<String, String[]> m = new HashMap<>();
            for (String[][] part : TrData.all()) {
                for (String[] e : part) m.put(e[0], new String[]{e[1], e[2]});
            }
            map = m;
        }
        return map;
    }

    public static String t(String zh) {
        if (zh == null) return null;
        String lang = forced != null ? forced : Locale.getDefault().getLanguage();
        if ("zh".equals(lang)) return zh;
        String[] v = map().get(zh);
        if (v == null) return zh;
        return "fa".equals(lang) ? v[1] : v[0];
    }
}
''')


# ---------- 5b) language chooser: hook Tr + add Persian ----------
up = JAVA + '/com/limelight/utils/UiHelper.java'
if os.path.exists(up):
    s = rd(up)
    marker = 'String locale = PreferenceConfiguration.readPreferences(activity).language;'
    if marker in s and 'Tr.setLang' not in s:
        wr(up, s.replace(marker, marker + '\n        com.limelight.utils.Tr.setLang(locale);', 1)); stats['uihelper'] = 1
ap = RES + 'values/arrays.xml'
at = rd(ap)
def add_item(text, name, item):
    def f(m):
        if '>%s<' % item in m.group(2): return m.group(0)
        return m.group(1) + m.group(2).rstrip() + '\n        <item>%s</item>\n    ' % item + m.group(3)
    return re.sub(r'(<string-array\b[^>]*name="%s"[^>]*>)(.*?)(</string-array>)' % name, f, text, count=1, flags=re.S)
at2 = add_item(add_item(at, 'language_names', '\u0641\u0627\u0631\u0633\u06cc'), 'language_values', 'fa')
if at2 != at: wr(ap, at2); stats['lang_fa'] = 1

# ---------- 6) manifest: RTL ----------
mp = ROOT + '/app/src/main/AndroidManifest.xml'
mt = rd(mp)
if 'supportsRtl' not in mt:
    mt = mt.replace('<application', '<application\n        android:supportsRtl="true"', 1)
    wr(mp, mt); stats['rtl'] = 1

# ---------- 7) sanity: every touched xml must parse ----------
bad = 0
for d in sorted(os.listdir(RES)):
    for f in os.listdir(RES + d):
        if f.endswith('.xml'):
            try: ET.parse(RES + d + '/' + f)
            except Exception as e: bad += 1; print('XML ERROR', d, f, e)
ET.parse(mp)
print(dict(stats))
for w in warn[:20]: print('WARN', w)
print('xml errors:', bad, ' warnings:', len(warn))
if bad: sys.exit(1)
