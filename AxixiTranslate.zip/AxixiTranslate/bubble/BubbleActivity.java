package com.limelight.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;

import com.limelight.binding.PlatformBinding;
import com.limelight.computers.ComputerDatabaseManager;
import com.limelight.computers.IdentityManager;
import com.limelight.nvstream.http.ComputerDetails;
import com.limelight.nvstream.http.NvApp;
import com.limelight.nvstream.http.NvHTTP;

import java.util.ArrayList;
import java.util.List;

/** Setup screen of the floating bubble: pick a paired PC and app, choose the layers, start / stop. */
public class BubbleActivity extends Activity {
    private SharedPreferences prefs;
    private final List<ComputerDetails> computers = new ArrayList<>();
    private final List<NvApp> apps = new ArrayList<>();
    private Spinner pcSpinner, appSpinner;
    private TextView permissionBtn, status;
    private int loadGen = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        BubbleKit.initLang(this);
        prefs = BubbleKit.prefs(this);
        setTitle(BubbleKit.tr("Axixi Bubble", "حباب Axixi"));

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF121212);
        sv.setFillViewport(true);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = BubbleKit.dp(this, 18);
        box.setPadding(pad, pad * 2, pad, pad);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_LOCALE);
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        box.addView(label(BubbleKit.tr("Floating bubble", "حباب شناور"), 24, true));
        TextView sub = label(BubbleKit.tr(
                "Use Axixi's on-screen controls over any other app. The bubble connects to your PC without opening a stream window.",
                "کنترل‌های روی صفحه‌ی Axixi را روی هر برنامه‌ی دیگری استفاده کنید. حباب بدون باز کردن پنجره‌ی استریم به رایانه وصل می‌شود."), 13, false);
        sub.setAlpha(0.75f);
        box.addView(sub);

        permissionBtn = button(BubbleKit.tr("Allow display over other apps", "اجازه‌ی نمایش روی برنامه‌های دیگر"), 0xFFE65100, new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            }
        });
        box.addView(permissionBtn, margin(16));

        box.addView(label(BubbleKit.tr("Computer", "رایانه"), 14, true), margin(18));
        pcSpinner = new Spinner(this);
        box.addView(pcSpinner, margin(4));
        box.addView(label(BubbleKit.tr("App to join", "برنامه‌ی هدف"), 14, true), margin(14));
        appSpinner = new Spinner(this);
        box.addView(appSpinner, margin(4));
        status = label("", 12, false);
        status.setAlpha(0.7f);
        box.addView(status, margin(4));

        box.addView(label(BubbleKit.tr("Controls", "کنترل‌ها"), 14, true), margin(18));
        box.addView(check(BubbleKit.tr("Gamepad layer", "لایه‌ی گیم‌پد"), BubbleKit.K_GAMEPAD, true));
        box.addView(check(BubbleKit.tr("Buttons / mouse layer", "لایه‌ی دکمه‌ها و ماوس"), BubbleKit.K_BUTTONS, true));
        box.addView(check(BubbleKit.tr("Full keyboard layer", "لایه‌ی کیبورد کامل"), BubbleKit.K_KEYBOARD, false));
        box.addView(check(BubbleKit.tr("Bubble hides at the screen edge when idle", "حباب در حالت بیکاری کنار صفحه پنهان شود"), BubbleKit.K_SLEEP, true));

        box.addView(button(BubbleKit.tr("Start bubble", "شروع حباب"), 0xFF3D5AFE, new View.OnClickListener() {
            @Override public void onClick(View v) { start(); }
        }), margin(22));
        box.addView(button(BubbleKit.tr("Stop bubble", "توقف حباب"), 0xFF455A64, new View.OnClickListener() {
            @Override public void onClick(View v) {
                startService(new Intent(BubbleActivity.this, BubbleService.class).setAction(BubbleService.ACTION_STOP));
            }
        }), margin(8));
        TextView tip = label(BubbleKit.tr(
                "Tap the bubble to show or hide the controls, long-press it for the quick panel. Layouts are the ones you edit in the Axixi stream menu.",
                "برای نمایش یا پنهان کردن کنترل‌ها حباب را لمس کنید و برای پنل سریع نگه دارید. چیدمان‌ها همان‌هایی هستند که در منوی استریم Axixi ویرایش می‌کنید."), 12, false);
        tip.setAlpha(0.6f);
        box.addView(tip, margin(16));
        setContentView(sv);

        loadComputers();
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        permissionBtn.setVisibility(Settings.canDrawOverlays(this) ? View.GONE : View.VISIBLE);
    }

    private ViewGroup.MarginLayoutParams margin(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = BubbleKit.dp(this, topDp);
        return lp;
    }

    private TextView label(String s, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextDirection(View.TEXT_DIRECTION_LOCALE);
        return t;
    }

    private TextView button(String s, int color, View.OnClickListener l) {
        TextView t = label(s, 15, true);
        t.setGravity(Gravity.CENTER);
        int p = BubbleKit.dp(this, 14);
        t.setPadding(p, p, p, p);
        t.setBackground(BubbleKit.rounded(color, BubbleKit.dp(this, 12)));
        t.setOnClickListener(l);
        return t;
    }

    private CheckBox check(String s, final String key, boolean def) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setTextColor(Color.WHITE);
        c.setChecked(prefs.getBoolean(key, def));
        c.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                prefs.edit().putBoolean(key, on).apply();
            }
        });
        return c;
    }

    private void loadComputers() {
        computers.clear();
        ComputerDatabaseManager db = null;
        try {
            db = new ComputerDatabaseManager(this);
            for (ComputerDetails c : db.getAllComputers()) {
                if (c.serverCert != null) computers.add(c); // paired only
            }
        } catch (Throwable ignored) {
        } finally {
            if (db != null) { try { db.close(); } catch (Throwable ignored) {} }
        }
        List<String> names = new ArrayList<>();
        int sel = 0;
        String saved = prefs.getString(BubbleKit.K_UUID, null);
        for (int i = 0; i < computers.size(); i++) {
            names.add(computers.get(i).name);
            if (computers.get(i).uuid != null && computers.get(i).uuid.equals(saved)) sel = i;
        }
        if (names.isEmpty()) {
            names.add(BubbleKit.tr("No paired PC — pair one in Axixi first", "رایانه‌ی جفت‌شده‌ای نیست — ابتدا در Axixi جفت کنید"));
        }
        pcSpinner.setAdapter(spinnerAdapter(names));
        pcSpinner.setSelection(sel);
        pcSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { loadApps(); }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
    }

    private ArrayAdapter<String> spinnerAdapter(List<String> items) {
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override public View getView(int pos, View cv, ViewGroup parent) {
                TextView t = (TextView) super.getView(pos, cv, parent);
                t.setTextColor(Color.WHITE);
                return t;
            }
            @Override public View getDropDownView(int pos, View cv, ViewGroup parent) {
                TextView t = (TextView) super.getDropDownView(pos, cv, parent);
                t.setTextColor(Color.WHITE);
                t.setBackgroundColor(0xFF263238);
                return t;
            }
        };
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return a;
    }

    private ComputerDetails selectedComputer() {
        int i = pcSpinner.getSelectedItemPosition();
        return i >= 0 && i < computers.size() ? computers.get(i) : null;
    }

    private void loadApps() {
        final ComputerDetails c = selectedComputer();
        apps.clear();
        appSpinner.setAdapter(spinnerAdapter(new ArrayList<String>()));
        if (c == null) return;
        final int gen = ++loadGen;
        status.setText(BubbleKit.tr("Loading apps…", "در حال دریافت برنامه‌ها…"));
        new Thread(new Runnable() {
            @Override public void run() {
                final List<NvApp> found = new ArrayList<>();
                String err = null;
                try {
                    ComputerDetails.AddressTuple addr = c.preferredAddress != null ? c.preferredAddress
                            : c.activeAddress != null ? c.activeAddress
                            : c.manualAddress != null ? c.manualAddress
                            : c.localAddress != null ? c.localAddress
                            : c.ipv6Address != null ? c.ipv6Address : c.remoteAddress;
                    NvHTTP http = new NvHTTP(addr, c.httpsPort != 0 ? c.httpsPort : 47984,
                            new IdentityManager(BubbleActivity.this).getUniqueId(), c.serverCert,
                            PlatformBinding.getCryptoProvider(BubbleActivity.this));
                    found.addAll(http.getAppList());
                } catch (Throwable t) {
                    err = t.getMessage() != null ? t.getMessage() : t.toString();
                }
                final String error = err;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (gen != loadGen || isFinishing()) return;
                        apps.clear();
                        apps.addAll(found);
                        List<String> names = new ArrayList<>();
                        int sel = 0;
                        int savedId = prefs.getInt(BubbleKit.K_APP_ID, -1);
                        for (int i = 0; i < apps.size(); i++) {
                            names.add(apps.get(i).getAppName());
                            if (apps.get(i).getAppId() == savedId) sel = i;
                        }
                        if (names.isEmpty()) {
                            names.add("Desktop");
                            status.setText(error != null
                                    ? BubbleKit.tr("Could not load the app list (PC offline?): ", "دریافت فهرست برنامه‌ها ممکن نشد (رایانه خاموش است؟): ") + error
                                    : "");
                        } else {
                            status.setText("");
                        }
                        appSpinner.setAdapter(spinnerAdapter(names));
                        appSpinner.setSelection(sel);
                    }
                });
            }
        }, "bubble-apps").start();
    }

    private void start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, BubbleKit.tr("Allow \"display over other apps\" first",
                    "ابتدا مجوز نمایش روی برنامه‌های دیگر را بدهید"), Toast.LENGTH_LONG).show();
            return;
        }
        ComputerDetails c = selectedComputer();
        if (c == null || c.uuid == null) {
            Toast.makeText(this, BubbleKit.tr("Pair a PC in Axixi first", "ابتدا یک رایانه را در Axixi جفت کنید"), Toast.LENGTH_LONG).show();
            return;
        }
        int ai = appSpinner.getSelectedItemPosition();
        int appId = 0;
        String appName = "Desktop";
        if (ai >= 0 && ai < apps.size()) { appId = apps.get(ai).getAppId(); appName = apps.get(ai).getAppName(); }
        Intent i = new Intent(this, BubbleService.class).setAction(BubbleService.ACTION_START)
                .putExtra(BubbleService.EXTRA_UUID, c.uuid)
                .putExtra(BubbleService.EXTRA_APP_ID, appId)
                .putExtra(BubbleService.EXTRA_APP_NAME, appName);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
        Toast.makeText(this, BubbleKit.tr("Bubble started — switch to any app", "حباب شروع شد — به هر برنامه‌ای بروید"), Toast.LENGTH_SHORT).show();
        finish();
    }
}
