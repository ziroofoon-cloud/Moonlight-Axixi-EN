package com.limelight.binding.input;

/** Anything that can receive the virtual gamepad state (the real stream or the floating bubble session). */
public interface OscSink {
    void reportOscState(int buttonFlags,
                        short leftStickX, short leftStickY,
                        short rightStickX, short rightStickY,
                        byte leftTrigger, byte rightTrigger);
}
