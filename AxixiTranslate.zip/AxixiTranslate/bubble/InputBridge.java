package com.limelight.binding.input;

import android.os.Handler;
import android.os.Looper;

import com.limelight.Game;

/**
 * Single entry point for the on-screen controls (buttons, mouse pad, keyboard).
 * While a stream is open in {@link Game} the input goes there; otherwise it goes to the floating
 * bubble session (see com.limelight.overlay.HeadlessSession).
 */
public final class InputBridge {
    public interface Target {
        boolean isConnected();
        void keyboardEvent(boolean down, short keyCode);
        void mouseButtonEvent(int buttonId, boolean down);
        void mouseMove(int dx, int dy);
        void mouseHighResScroll(boolean up);
        void toggleSoftKeyboard();
        /** Special shortcut codes 8..13 (see KeyBoardController.sendAssembleKey). */
        void special(int value);
    }

    private static volatile Target overlay;

    private InputBridge() {}

    public static void setOverlayTarget(Target t) { overlay = t; }

    public static Target getOverlayTarget() { return overlay; }

    private static Game game() {
        Game g = Game.instance;
        return (g != null && g.connected) ? g : null;
    }

    public static boolean isConnected() {
        if (game() != null) return true;
        Target t = overlay;
        return t != null && t.isConnected();
    }

    public static void keyboardEvent(boolean down, short keyCode) {
        Game g = game();
        if (g != null) { g.keyboardEvent(down, keyCode); return; }
        Target t = overlay;
        if (t != null) t.keyboardEvent(down, keyCode);
    }

    public static void mouseButtonEvent(int buttonId, boolean down) {
        Game g = game();
        if (g != null) { g.mouseButtonEvent(buttonId, down); return; }
        Target t = overlay;
        if (t != null) t.mouseButtonEvent(buttonId, down);
    }

    public static void mouseMove(int dx, int dy) {
        Game g = game();
        if (g != null) { g.mouseMove(dx, dy); return; }
        Target t = overlay;
        if (t != null) t.mouseMove(dx, dy);
    }

    public static void mouseHighResScroll(boolean up) {
        Game g = game();
        if (g != null) { g.mouseHighResScroll(up); return; }
        Target t = overlay;
        if (t != null) t.mouseHighResScroll(up);
    }

    public static void toggleSoftKeyboard() {
        final Game g = game();
        if (g != null) {
            if (!g.hasWindowFocus()) {
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override public void run() { g.toggleKeyboard(); }
                }, 10);
            } else {
                g.toggleKeyboard();
            }
            return;
        }
        Target t = overlay;
        if (t != null) t.toggleSoftKeyboard();
    }

    /** 8 buttons layer, 9 keyboard layer, 10 gamepad layer, 11 floating ball, 12 HUD, 13 quick menu. */
    public static void special(int value) {
        Game g = game();
        if (g != null) {
            switch (value) {
                case 8: g.showHideKeyboardController(); break;
                case 9: g.showHidekeyBoardLayoutController(); break;
                case 10: g.showHideVirtualController(); break;
                case 11: g.switchFloatView(); break;
                case 12: g.showHUD(); break;
                case 13: g.showGameMenu(); break;
                default: break;
            }
            return;
        }
        Target t = overlay;
        if (t != null) t.special(value);
    }
}
