package com.limelight.overlay;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.limelight.R;
import com.limelight.binding.input.InputBridge;
import com.limelight.binding.input.virtual_controller.keyboard.KeyBoardController;
import com.limelight.binding.input.virtual_controller.keyboard.KeyBoardLayoutController;
import com.limelight.computers.ComputerDatabaseManager;
import com.limelight.nvstream.http.ComputerDetails;
import com.limelight.preferences.PreferenceConfiguration;

/**
 * Floating bubble over other apps. Tap = show / hide the on-screen controls (Axixi's own gamepad,
 * button and keyboard layers), long press = quick panel. The bubble docks to a screen edge and
 * slides half out of sight when idle.
 */
public class BubbleService extends Service implements HeadlessSession.SpecialListener {
    public static final String ACTION_START = "com.limelight.overlay.BUBBLE_START";
    public static final String ACTION_STOP = "com.limelight.overlay.BUBBLE_STOP";
    public static final String EXTRA_UUID = "uuid";
    public static final String EXTRA_APP_ID = "app_id";
    public static final String EXTRA_APP_NAME = "app_name";

    private static final int NOTIF_ID = 7301;
    private static final String CHANNEL = "axixi_bubble";
    private static final int ACCENT = 0xFF3D5AFE;
    private static final long SLEEP_DELAY_MS = 3500;

    private static volatile boolean running;
    private static HeadlessSession sharedSession;

    public static boolean isRunning() { return running; }

    static synchronized HeadlessSession session(Context c) {
        if (sharedSession == null) sharedSession = new HeadlessSession(c.getApplicationContext());
        return sharedSession;
    }

    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private SharedPreferences prefs;
    private HeadlessSession session;

    private FrameLayout bubble;
    private TextView glyph;
    private View dot;
    private WindowManager.LayoutParams bubbleLp;
    private boolean sleeping;
    private boolean dragging;
    private int side; // 0 left, 1 right
    private ValueAnimator anim;

    private FrameLayout layerRoot;
    private boolean layerActive;
    private KeyBoardController gamepadCtl;
    private KeyBoardController buttonsCtl;
    private KeyBoardLayoutController keyboardCtl;

    private View panel;
    private WindowManager.LayoutParams panelLp;
    private HeadlessSession.State lastState = HeadlessSession.State.IDLE;

    private final Runnable sleepRunnable = new Runnable() {
        @Override public void run() { goToSleep(); }
    };
    private final Runnable stateListener = new Runnable() {
        @Override public void run() { onSessionChanged(); }
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        BubbleKit.initLang(this);
        prefs = BubbleKit.prefs(this);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        session = session(this);
        running = true;
        startAsForeground();
        if (!Settings.canDrawOverlays(this)) {
            toast(BubbleKit.tr("Allow \"display over other apps\" first",
                    "ابتدا مجوز نمایش روی برنامه‌های دیگر را بدهید"));
            stopSelf();
            return;
        }
        session.addListener(stateListener);
        session.setSpecialHandler(this);
        InputBridge.setOverlayTarget(session);
        addBubble();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_START.equals(intent.getAction())) {
            String uuid = intent.getStringExtra(EXTRA_UUID);
            if (uuid != null) {
                prefs.edit().putString(BubbleKit.K_UUID, uuid)
                        .putInt(BubbleKit.K_APP_ID, intent.getIntExtra(EXTRA_APP_ID, 0))
                        .putString(BubbleKit.K_APP_NAME, intent.getStringExtra(EXTRA_APP_NAME))
                        .apply();
                connectSaved();
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        main.removeCallbacksAndMessages(null);
        if (anim != null) anim.cancel();
        dismissPanel();
        deactivateLayer();
        removeBubble();
        if (session != null) {
            session.removeListener(stateListener);
            session.setSpecialHandler(null);
            session.disconnect();
        }
        if (InputBridge.getOverlayTarget() == session) InputBridge.setOverlayTarget(null);
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (bubble != null) {
            placeBubble(false);
        }
        if (layerActive) {
            // Layouts differ between portrait and landscape: build the layer again.
            deactivateLayer();
            activateLayer();
        }
    }

    // ---- foreground notification ---------------------------------------------------------------

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL,
                    BubbleKit.tr("Floating bubble", "حباب شناور"), NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        Intent stop = new Intent(this, BubbleService.class).setAction(ACTION_STOP);
        int pf = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, pf);
        Intent open = new Intent(this, BubbleActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 2, open, pf);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_bubble_notif)
                .setContentTitle(BubbleKit.tr("Axixi bubble is active", "حباب Axixi فعال است"))
                .setContentText(BubbleKit.tr("Tap to open the settings", "برای باز کردن تنظیمات لمس کنید"))
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(0,
                        BubbleKit.tr("Quit", "خروج"), stopPi).build());
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Throwable t) {
            stopSelf();
        }
    }

    // ---- connection ----------------------------------------------------------------------------

    private void connectSaved() {
        String uuid = prefs.getString(BubbleKit.K_UUID, null);
        if (uuid == null) {
            toast(BubbleKit.tr("Choose a PC first", "ابتدا یک رایانه انتخاب کنید"));
            return;
        }
        ComputerDatabaseManager db = null;
        ComputerDetails c = null;
        try {
            db = new ComputerDatabaseManager(this);
            c = db.getComputerByUUID(uuid);
        } catch (Throwable ignored) {
        } finally {
            if (db != null) { try { db.close(); } catch (Throwable ignored) {} }
        }
        if (c == null) {
            toast(BubbleKit.tr("This PC is no longer in the list", "این رایانه دیگر در فهرست نیست"));
            return;
        }
        session.connect(c, prefs.getInt(BubbleKit.K_APP_ID, 0), prefs.getString(BubbleKit.K_APP_NAME, "Desktop"));
    }

    private void onSessionChanged() {
        HeadlessSession.State s = session.getState();
        if (s == HeadlessSession.State.FAILED && lastState != HeadlessSession.State.FAILED) {
            String m = session.getMessage();
            toast(BubbleKit.tr("Connection failed", "اتصال برقرار نشد") + (m.isEmpty() ? "" : ": " + m));
        }
        if (s != HeadlessSession.State.CONNECTED && layerActive && s != HeadlessSession.State.CONNECTING) {
            deactivateLayer();
        }
        lastState = s;
        refreshLook();
        if (panel != null) rebuildPanel();
    }

    // ---- bubble --------------------------------------------------------------------------------

    private DisplayMetrics metrics() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return dm;
    }

    private int sizePx() { return BubbleKit.dp(this, prefs.getInt(BubbleKit.K_SIZE, 52)); }

    private int inset() { return BubbleKit.dp(this, 6); }

    private int restX(int size) {
        DisplayMetrics dm = metrics();
        return side == 0 ? inset() : dm.widthPixels - size - inset();
    }

    private void addBubble() {
        int size = sizePx();
        DisplayMetrics dm = metrics();
        side = prefs.getInt(BubbleKit.K_X, 0) > dm.widthPixels / 2 ? 1 : 0;

        bubble = new FrameLayout(this);
        glyph = new TextView(this);
        glyph.setText("A");
        glyph.setTextColor(Color.WHITE);
        glyph.setTypeface(Typeface.DEFAULT_BOLD);
        glyph.setGravity(Gravity.CENTER);
        glyph.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * 0.46f);
        glyph.setBackground(BubbleKit.circle(ACCENT));
        bubble.addView(glyph, new FrameLayout.LayoutParams(size, size));

        int ds = Math.max(BubbleKit.dp(this, 8), (int) (size * 0.24f));
        dot = new View(this);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(ds, ds, Gravity.TOP | Gravity.END);
        bubble.addView(dot, dlp);

        bubbleLp = new WindowManager.LayoutParams(size, size, BubbleKit.overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        applyCutout(bubbleLp);
        bubbleLp.x = restX(size);
        bubbleLp.y = Math.max(0, Math.min(prefs.getInt(BubbleKit.K_Y, dm.heightPixels / 3), dm.heightPixels - size));
        attachTouch();
        try { wm.addView(bubble, bubbleLp); } catch (Throwable t) { stopSelf(); return; }
        refreshLook();
        scheduleSleep();
    }

    private static void applyCutout(WindowManager.LayoutParams lp) {
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
    }

    private void removeBubble() {
        if (bubble != null) {
            try { wm.removeView(bubble); } catch (Throwable ignored) {}
            bubble = null;
        }
    }

    private void refreshLook() {
        if (bubble == null) return;
        int c;
        switch (session.getState()) {
            case CONNECTED: c = 0xFF2ECC71; break;
            case CONNECTING: c = 0xFFF1C40F; break;
            case FAILED: c = 0xFFE74C3C; break;
            default: c = 0xFF95A5A6;
        }
        dot.setBackground(BubbleKit.circle(c));
        glyph.setBackground(BubbleKit.circle(layerActive ? 0xFF00C853 : ACCENT));
        bubble.setAlpha(sleeping ? 0.45f : 1f);
    }

    private void placeBubble(boolean animate) {
        if (bubble == null) return;
        int size = sizePx();
        DisplayMetrics dm = metrics();
        int y = Math.max(0, Math.min(bubbleLp.y, dm.heightPixels - size));
        moveTo(sleeping ? sleepX(size) : restX(size), y, animate);
    }

    private int sleepX(int size) {
        int hidden = (int) (size * 0.55f);
        DisplayMetrics dm = metrics();
        return side == 0 ? -hidden : dm.widthPixels - size + hidden;
    }

    private void moveTo(final int x, final int y, boolean animate) {
        if (bubble == null) return;
        if (anim != null) anim.cancel();
        if (!animate) {
            bubbleLp.x = x; bubbleLp.y = y;
            updateBubble();
            return;
        }
        final int fx = bubbleLp.x, fy = bubbleLp.y;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(180);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                float t = (Float) a.getAnimatedValue();
                bubbleLp.x = (int) (fx + (x - fx) * t);
                bubbleLp.y = (int) (fy + (y - fy) * t);
                updateBubble();
            }
        });
        anim.start();
    }

    private void updateBubble() {
        if (bubble == null) return;
        try { wm.updateViewLayout(bubble, bubbleLp); } catch (Throwable ignored) {}
    }

    private void scheduleSleep() {
        main.removeCallbacks(sleepRunnable);
        if (prefs.getBoolean(BubbleKit.K_SLEEP, true)) main.postDelayed(sleepRunnable, SLEEP_DELAY_MS);
    }

    private void goToSleep() {
        if (bubble == null || dragging || layerActive || panel != null) return;
        sleeping = true;
        placeBubble(true);
        refreshLook();
    }

    private void wake() {
        main.removeCallbacks(sleepRunnable);
        if (!sleeping) return;
        sleeping = false;
        placeBubble(true);
        refreshLook();
    }

    private void attachTouch() {
        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean moved, longFired;
            final Runnable longPress = new Runnable() {
                @Override public void run() { longFired = true; if (!moved) showPanel(); }
            };
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        wake();
                        if (anim != null) anim.cancel();
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = bubbleLp.x; startY = bubbleLp.y;
                        moved = false; longFired = false; dragging = true;
                        main.postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (!moved && Math.hypot(dx, dy) > slop) {
                            moved = true;
                            main.removeCallbacks(longPress);
                            dismissPanel();
                        }
                        if (moved) {
                            bubbleLp.x = startX + (int) dx;
                            bubbleLp.y = startY + (int) dy;
                            updateBubble();
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        main.removeCallbacks(longPress);
                        dragging = false;
                        if (moved) {
                            DisplayMetrics dm = metrics();
                            int cx = bubbleLp.x + sizePx() / 2;
                            side = cx > dm.widthPixels / 2 ? 1 : 0;
                            int size = sizePx();
                            int y = Math.max(0, Math.min(bubbleLp.y, dm.heightPixels - size));
                            prefs.edit().putInt(BubbleKit.K_X, side == 1 ? dm.widthPixels : 0).putInt(BubbleKit.K_Y, y).apply();
                            moveTo(restX(size), y, true);
                        } else if (!longFired && e.getActionMasked() == MotionEvent.ACTION_UP) {
                            onTap();
                        }
                        scheduleSleep();
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void onTap() {
        if (panel != null) { dismissPanel(); return; }
        if (layerActive) { deactivateLayer(); return; }
        if (session.getState() == HeadlessSession.State.IDLE || session.getState() == HeadlessSession.State.FAILED) {
            connectSaved();
            return;
        }
        if (session.getState() == HeadlessSession.State.CONNECTING) {
            toast(BubbleKit.tr("Connecting…", "در حال اتصال…"));
            return;
        }
        activateLayer();
    }

    // ---- control layer ---------------------------------------------------------------------------

    private void activateLayer() {
        if (layerActive || !session.isConnected()) return;
        dismissPanel();
        Context themed = new ContextThemeWrapper(this, R.style.StreamTheme);
        layerRoot = new FrameLayout(themed);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
                BubbleKit.overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        applyCutout(lp);
        try { wm.addView(layerRoot, lp); } catch (Throwable t) { layerRoot = null; return; }
        layerActive = true;

        PreferenceConfiguration pc = PreferenceConfiguration.readPreferences(themed);
        try {
            if (prefs.getBoolean(BubbleKit.K_GAMEPAD, true)) {
                gamepadCtl = new KeyBoardController(session, layerRoot, themed, pc, true);
                gamepadCtl.show();
            }
            if (prefs.getBoolean(BubbleKit.K_BUTTONS, true)) {
                buttonsCtl = new KeyBoardController(session, layerRoot, themed, pc, false);
                buttonsCtl.show();
            }
            if (prefs.getBoolean(BubbleKit.K_KEYBOARD, false)) {
                keyboardCtl = new KeyBoardLayoutController(session, layerRoot, themed, pc);
                keyboardCtl.refreshLayout();
                keyboardCtl.show();
            }
        } catch (Throwable t) {
            toast("Layer error: " + t);
        }
        layerRoot.setAlpha(prefs.getInt(BubbleKit.K_OPACITY, 100) / 100f);
        raiseBubble();
        refreshLook();
    }

    private void deactivateLayer() {
        if (layerRoot != null) {
            try { wm.removeView(layerRoot); } catch (Throwable ignored) {}
            layerRoot = null;
        }
        gamepadCtl = null; buttonsCtl = null; keyboardCtl = null;
        boolean was = layerActive;
        layerActive = false;
        if (was) { refreshLook(); scheduleSleep(); }
    }

    /** The layer window covers everything added before it: put the bubble back on top. */
    private void raiseBubble() {
        if (bubble == null) return;
        try { wm.removeView(bubble); } catch (Throwable ignored) {}
        try { wm.addView(bubble, bubbleLp); } catch (Throwable ignored) {}
    }

    private void restartLayer() {
        if (!layerActive) return;
        deactivateLayer();
        activateLayer();
    }

    /** Special shortcut codes pressed on the on-screen controls (see InputBridge.special). */
    @Override
    public void onSpecial(int value) {
        switch (value) {
            case 8: prefs.edit().putBoolean(BubbleKit.K_BUTTONS, !prefs.getBoolean(BubbleKit.K_BUTTONS, true)).apply(); restartLayer(); break;
            case 9: prefs.edit().putBoolean(BubbleKit.K_KEYBOARD, !prefs.getBoolean(BubbleKit.K_KEYBOARD, false)).apply(); restartLayer(); break;
            case 10: prefs.edit().putBoolean(BubbleKit.K_GAMEPAD, !prefs.getBoolean(BubbleKit.K_GAMEPAD, true)).apply(); restartLayer(); break;
            case 13: showPanel(); break;
            default: break;
        }
    }

    private void startEditMode() {
        if (!layerActive) activateLayer();
        dismissPanel();
        if (gamepadCtl != null) gamepadCtl.switchMode(KeyBoardController.ControllerMode.MoveButtons);
        else if (buttonsCtl != null) buttonsCtl.switchMode(KeyBoardController.ControllerMode.MoveButtons);
        else toast(BubbleKit.tr("Turn on the gamepad or buttons layer first", "ابتدا لایه‌ی گیم‌پد یا دکمه‌ها را روشن کنید"));
    }

    // ---- quick panel -----------------------------------------------------------------------------

    private void showPanel() {
        if (panel != null || bubble == null) return;
        wake();
        panel = buildPanel();
        panelLp = new WindowManager.LayoutParams(BubbleKit.dp(this, 270), ViewGroup.LayoutParams.WRAP_CONTENT,
                BubbleKit.overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        DisplayMetrics dm = metrics();
        int pw = BubbleKit.dp(this, 270);
        panelLp.x = side == 0 ? sizePx() + inset() * 2 : dm.widthPixels - pw - sizePx() - inset() * 2;
        panelLp.y = Math.max(BubbleKit.dp(this, 24), Math.min(bubbleLp.y, dm.heightPixels / 3));
        try { wm.addView(panel, panelLp); } catch (Throwable t) { panel = null; return; }
        raiseBubble();
    }

    private void dismissPanel() {
        if (panel != null) {
            try { wm.removeView(panel); } catch (Throwable ignored) {}
            panel = null;
        }
        scheduleSleep();
    }

    private void rebuildPanel() {
        if (panel == null) return;
        try { wm.removeView(panel); } catch (Throwable ignored) {}
        panel = buildPanel();
        try { wm.addView(panel, panelLp); } catch (Throwable t) { panel = null; }
        raiseBubble();
    }

    private TextView text(Context c, String s, float sp, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextDirection(View.TEXT_DIRECTION_LOCALE);
        return t;
    }

    private TextView button(Context c, String label, int color, View.OnClickListener l) {
        TextView t = text(c, label, 13, true);
        t.setGravity(Gravity.CENTER);
        int p = BubbleKit.dp(c, 8);
        t.setPadding(p, p, p, p);
        t.setBackground(BubbleKit.rounded(color, BubbleKit.dp(c, 10)));
        t.setOnClickListener(l);
        return t;
    }

    private View buildPanel() {
        final Context c = new ContextThemeWrapper(this, R.style.StreamTheme);
        int pad = BubbleKit.dp(c, 12);
        int gap = BubbleKit.dp(c, 8);

        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        box.setBackground(BubbleKit.rounded(0xF2202124, BubbleKit.dp(c, 16)));
        box.setLayoutDirection(View.LAYOUT_DIRECTION_LOCALE);

        String pc = session.getPcName().isEmpty() ? BubbleKit.tr("Not connected", "متصل نیست") : session.getPcName();
        String st;
        switch (session.getState()) {
            case CONNECTED: st = BubbleKit.tr("Connected", "متصل"); break;
            case CONNECTING: st = BubbleKit.tr("Connecting…", "در حال اتصال…"); break;
            case FAILED: st = BubbleKit.tr("Failed", "ناموفق"); break;
            default: st = BubbleKit.tr("Idle", "آماده");
        }
        box.addView(text(c, pc, 16, true));
        TextView stv = text(c, st + (session.getMessage().isEmpty() ? "" : " — " + session.getMessage()), 12, false);
        stv.setAlpha(0.7f);
        box.addView(stv);

        // layer toggles
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = gap;
        box.addView(row, rp);
        addToggle(c, row, BubbleKit.tr("Gamepad", "گیم‌پد"), BubbleKit.K_GAMEPAD, true);
        addToggle(c, row, BubbleKit.tr("Buttons", "دکمه‌ها"), BubbleKit.K_BUTTONS, true);
        addToggle(c, row, BubbleKit.tr("Keyboard", "کیبورد"), BubbleKit.K_KEYBOARD, false);

        addSeek(c, box, BubbleKit.tr("Opacity", "شفافیت"), 20, 100, prefs.getInt(BubbleKit.K_OPACITY, 100), new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                int v = Math.max(20, p);
                prefs.edit().putInt(BubbleKit.K_OPACITY, v).apply();
                if (layerRoot != null) layerRoot.setAlpha(v / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        addSeek(c, box, BubbleKit.tr("Bubble size", "اندازه‌ی حباب"), 36, 80, prefs.getInt(BubbleKit.K_SIZE, 52), new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {}
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {
                prefs.edit().putInt(BubbleKit.K_SIZE, Math.max(36, s.getProgress())).apply();
                rebuildBubble();
            }
        });

        LinearLayout row2 = new LinearLayout(c);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams r2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        r2.topMargin = gap;
        box.addView(row2, r2);
        addWeighted(row2, button(c, layerActive ? BubbleKit.tr("Hide controls", "پنهان‌سازی کنترل") : BubbleKit.tr("Show controls", "نمایش کنترل"), ACCENT, new View.OnClickListener() {
            @Override public void onClick(View v) {
                dismissPanel();
                if (layerActive) deactivateLayer(); else if (session.isConnected()) activateLayer();
                else connectSaved();
            }
        }), 0);
        addWeighted(row2, button(c, BubbleKit.tr("Edit layout", "ویرایش چیدمان"), 0xFF455A64, new View.OnClickListener() {
            @Override public void onClick(View v) { startEditMode(); }
        }), gap);

        LinearLayout row3 = new LinearLayout(c);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams r3 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        r3.topMargin = gap;
        box.addView(row3, r3);
        final boolean up = session.getState() == HeadlessSession.State.CONNECTED || session.getState() == HeadlessSession.State.CONNECTING;
        addWeighted(row3, button(c, up ? BubbleKit.tr("Disconnect", "قطع اتصال") : BubbleKit.tr("Connect", "اتصال"), 0xFF455A64, new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (up) { deactivateLayer(); session.disconnect(); } else connectSaved();
            }
        }), 0);
        addWeighted(row3, button(c, BubbleKit.tr("Quit", "خروج"), 0xFFC62828, new View.OnClickListener() {
            @Override public void onClick(View v) { stopSelf(); }
        }), gap);

        // Tap outside closes the panel.
        final View root = box;
        root.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_OUTSIDE) { dismissPanel(); return true; }
                return false;
            }
        });
        return root;
    }

    private void addWeighted(LinearLayout row, View v, int startMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMarginStart(startMargin);
        row.addView(v, lp);
    }

    private void addToggle(Context c, LinearLayout row, String label, final String key, boolean def) {
        final TextView t = text(c, label, 12, true);
        t.setGravity(Gravity.CENTER);
        int p = BubbleKit.dp(c, 8);
        t.setPadding(p, p, p, p);
        final boolean[] on = { prefs.getBoolean(key, def) };
        final boolean dflt = def;
        t.setBackground(BubbleKit.rounded(on[0] ? ACCENT : 0xFF37474F, BubbleKit.dp(c, 10)));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                on[0] = !prefs.getBoolean(key, dflt);
                prefs.edit().putBoolean(key, on[0]).apply();
                t.setBackground(BubbleKit.rounded(on[0] ? ACCENT : 0xFF37474F, BubbleKit.dp(v.getContext(), 10)));
                restartLayer();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMarginEnd(BubbleKit.dp(c, 6));
        row.addView(t, lp);
    }

    private void addSeek(Context c, LinearLayout box, String label, int min, int max, int value, SeekBar.OnSeekBarChangeListener l) {
        TextView t = text(c, label, 12, false);
        t.setAlpha(0.8f);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = BubbleKit.dp(c, 8);
        box.addView(t, tp);
        SeekBar sb = new SeekBar(c);
        sb.setMax(max);
        sb.setProgress(Math.max(min, Math.min(max, value)));
        sb.setOnSeekBarChangeListener(l);
        box.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void rebuildBubble() {
        boolean hadPanel = panel != null;
        removeBubble();
        addBubble();
        if (hadPanel) { dismissPanel(); showPanel(); }
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }
}
