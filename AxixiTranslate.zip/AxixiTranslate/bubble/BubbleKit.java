package com.limelight.overlay;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.WindowManager;

import com.limelight.preferences.PreferenceConfiguration;
import com.limelight.utils.Tr;

/** Small shared helpers of the floating bubble feature. */
final class BubbleKit {
    private BubbleKit() {}

    static final String PREFS = "axixi_bubble";
    static final String K_UUID = "uuid";
    static final String K_APP_ID = "app_id";
    static final String K_APP_NAME = "app_name";
    static final String K_GAMEPAD = "gamepad";
    static final String K_BUTTONS = "buttons";
    static final String K_KEYBOARD = "keyboard";
    static final String K_OPACITY = "opacity";
    static final String K_SIZE = "size_dp";
    static final String K_X = "x";
    static final String K_Y = "y";
    static final String K_SLEEP = "auto_sleep";

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Applies the language chosen inside the app (same as the stream screens do). */
    static void initLang(Context c) {
        try { Tr.setLang(PreferenceConfiguration.readPreferences(c).language); } catch (Throwable ignored) {}
    }

    /** English / Persian text depending on the language chosen in the app. */
    static String tr(String en, String fa) {
        return "fa".equals(Tr.lang()) ? fa : en;
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    static GradientDrawable rounded(int color, float radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusPx);
        return d;
    }

    static GradientDrawable circle(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }
}
