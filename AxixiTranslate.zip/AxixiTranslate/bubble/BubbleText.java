package com.limelight.overlay;

/** Texts that other packages need from the bubble feature. */
public final class BubbleText {
    private BubbleText() {}

    public static String openEditorHint() {
        return BubbleKit.tr("Adding buttons works in the Axixi stream menu. Here you can move and resize.",
                "افزودن دکمه فقط در منوی استریم Axixi ممکن است. این‌جا می‌توانید جابه‌جا و تغییر اندازه دهید.");
    }
}
