package com.limelight.overlay;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;

import com.limelight.LimeLog;
import com.limelight.binding.PlatformBinding;
import com.limelight.binding.input.InputBridge;
import com.limelight.binding.input.KeyboardTranslator;
import com.limelight.binding.input.OscSink;
import com.limelight.computers.IdentityManager;
import com.limelight.nvstream.NvConnection;
import com.limelight.nvstream.NvConnectionListener;
import com.limelight.nvstream.StreamConfiguration;
import com.limelight.nvstream.av.audio.AudioRenderer;
import com.limelight.nvstream.av.video.VideoDecoderRenderer;
import com.limelight.nvstream.http.ComputerDetails;
import com.limelight.nvstream.http.NvApp;
import com.limelight.nvstream.input.ControllerPacket;
import com.limelight.nvstream.input.KeyboardPacket;
import com.limelight.nvstream.input.MouseButtonPacket;
import com.limelight.nvstream.jni.MoonBridge;
import com.limelight.preferences.PreferenceConfiguration;

import java.util.ArrayList;
import java.util.List;

/**
 * A connection to Sunshine / Apollo that only carries input. A tiny low-rate video stream is
 * negotiated (the host needs one) and thrown away, audio is discarded. It joins the session that is
 * already running on the PC instead of quitting it.
 */
public class HeadlessSession implements OscSink, InputBridge.Target {
    public enum State { IDLE, CONNECTING, CONNECTED, FAILED }

    private final Context appCtx;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final KeyboardTranslator translator = new KeyboardTranslator();
    private final List<Runnable> listeners = new ArrayList<>();

    private volatile State state = State.IDLE;
    private volatile String message = "";
    private volatile String pcName = "";
    private volatile NvConnection conn;
    private volatile int generation = 0;
    private int modifiers = 0;
    public interface SpecialListener { void onSpecial(int value); }
    private volatile SpecialListener specialHandler;

    public HeadlessSession(Context context) {
        this.appCtx = context.getApplicationContext();
    }

    public State getState() { return state; }
    public String getMessage() { return message; }
    public String getPcName() { return pcName; }
    public void setSpecialHandler(SpecialListener l) { specialHandler = l; }

    public void addListener(Runnable l) { synchronized (listeners) { listeners.add(l); } }
    public void removeListener(Runnable l) { synchronized (listeners) { listeners.remove(l); } }

    private void setState(State s, String msg) {
        state = s;
        message = msg == null ? "" : msg;
        main.post(new Runnable() {
            @Override public void run() {
                List<Runnable> copy;
                synchronized (listeners) { copy = new ArrayList<>(listeners); }
                for (Runnable r : copy) r.run();
            }
        });
    }

    @Override public boolean isConnected() { return state == State.CONNECTED; }

    private static ComputerDetails.AddressTuple pickAddress(ComputerDetails c) {
        if (c.preferredAddress != null) return c.preferredAddress;
        if (c.activeAddress != null) return c.activeAddress;
        if (c.manualAddress != null) return c.manualAddress;
        if (c.localAddress != null) return c.localAddress;
        if (c.ipv6Address != null) return c.ipv6Address;
        return c.remoteAddress;
    }

    public void connect(final ComputerDetails computer, final int appId, final String appName) {
        disconnect();
        final ComputerDetails.AddressTuple addr = pickAddress(computer);
        if (addr == null) { setState(State.FAILED, "No address"); return; }
        pcName = computer.name != null ? computer.name : addr.address;
        final int gen = ++generation;
        setState(State.CONNECTING, "");
        new Thread(new Runnable() {
            @Override public void run() { attempt(computer, addr, appId, appName, gen); }
        }, "bubble-connect").start();
    }

    private void attempt(ComputerDetails computer, ComputerDetails.AddressTuple addr,
                         int appId, String appName, final int gen) {
        try {
            NvApp app = new NvApp(appName == null || appName.isEmpty() ? "Desktop" : appName, appId, false);
            StreamConfiguration cfg = new StreamConfiguration.Builder()
                    .setApp(app)
                    .setResolution(640, 360)
                    .setLaunchRefreshRate(15)
                    .setRefreshRate(15)
                    .setBitrate(500)
                    .setMaxPacketSize(1392)
                    .setEnableSops(false)
                    .enableLocalAudioPlayback(false)
                    .setRemoteConfiguration(StreamConfiguration.STREAM_CFG_AUTO)
                    .setSupportedVideoFormats(MoonBridge.VIDEO_FORMAT_H264)
                    .setAttachedGamepadMask(1)
                    .setAudioConfiguration(MoonBridge.AUDIO_CONFIGURATION_STEREO)
                    .build();

            int httpsPort = computer.httpsPort != 0 ? computer.httpsPort : 47984;
            NvConnection c = new NvConnection(appCtx, addr, httpsPort,
                    new IdentityManager(appCtx).getUniqueId(), cfg,
                    PlatformBinding.getCryptoProvider(appCtx), computer.serverCert);
            c.setJoinExisting(true);
            conn = c;

            NvConnectionListener listener = new NvConnectionListener() {
                private boolean stale() { return gen != generation; }
                @Override public void stageStarting(String stage) {}
                @Override public void stageComplete(String stage) {}
                @Override public void stageFailed(String stage, int portFlags, int errorCode) {
                    if (stale()) return;
                    String m = lastHostMessage.length() > 0 ? lastHostMessage : ("Stage failed: " + stage + " (" + errorCode + ")");
                    setState(State.FAILED, m);
                }
                @Override public void connectionStarted() {
                    if (stale()) return;
                    setState(State.CONNECTED, "");
                    announceGamepad();
                }
                @Override public void connectionTerminated(int errorCode) {
                    if (stale()) return;
                    setState(State.FAILED, "Connection lost (" + errorCode + ")");
                }
                @Override public void connectionStatusUpdate(int connectionStatus) {}
                @Override public void displayMessage(String m) { lastHostMessage = m == null ? "" : m; LimeLog.info("Bubble: " + m); }
                @Override public void displayTransientMessage(String m) {}
                @Override public void rumble(short n, short low, short high) {}
                @Override public void rumbleTriggers(short n, short l, short r) {}
                @Override public void setHdrMode(boolean enabled, byte[] md) {}
                @Override public void setMotionEventState(short n, byte t, short hz) {}
                @Override public void setControllerLED(short n, byte r, byte g, byte b) {}
                @Override public void setAdaptiveTriggers(short n, byte f, byte tl, byte tr, byte[] l, byte[] r) {}
                @Override public void setPlayerIndicator(short n, byte p) {}
                @Override public void controllerPcm(short n, short seq, int rate, byte ch, byte bits, byte[] pcm) {}
            };
            lastHostMessage = "";
            c.start(STUB_AUDIO, STUB_VIDEO, listener);
        } catch (Throwable e) {
            LimeLog.warning("Bubble: connect failed: " + e);
            setState(State.FAILED, e.getMessage() != null ? e.getMessage() : e.toString());
        }
    }

    private volatile String lastHostMessage = "";

    private void announceGamepad() {
        NvConnection c = conn;
        if (c == null) return;
        try {
            int buttons = ControllerPacket.A_FLAG | ControllerPacket.B_FLAG | ControllerPacket.X_FLAG |
                    ControllerPacket.Y_FLAG | ControllerPacket.UP_FLAG | ControllerPacket.DOWN_FLAG |
                    ControllerPacket.LEFT_FLAG | ControllerPacket.RIGHT_FLAG | ControllerPacket.LB_FLAG |
                    ControllerPacket.RB_FLAG | ControllerPacket.PLAY_FLAG | ControllerPacket.BACK_FLAG |
                    ControllerPacket.LS_CLK_FLAG | ControllerPacket.RS_CLK_FLAG |
                    ControllerPacket.SPECIAL_BUTTON_FLAG;
            c.sendControllerArrivalEvent((byte) 0, (short) 1, MoonBridge.LI_CTYPE_XBOX, buttons,
                    MoonBridge.LI_CCAP_ANALOG_TRIGGERS);
        } catch (Throwable e) {
            LimeLog.warning("Bubble: arrival event failed: " + e);
        }
    }

    public void disconnect() {
        generation++;
        NvConnection c = conn;
        conn = null;
        if (c != null) {
            try { c.stop(); } catch (Throwable ignored) {}
        }
        modifiers = 0;
        if (state != State.IDLE) setState(State.IDLE, "");
    }

    // ---- input -------------------------------------------------------------------------------

    @Override
    public void reportOscState(int buttonFlags, short lx, short ly, short rx, short ry, byte lt, byte rt) {
        NvConnection c = conn;
        if (c == null || state != State.CONNECTED) return;
        c.sendControllerInput((short) 0, (short) 1, buttonFlags, lt, rt, lx, ly, rx, ry);
    }

    @Override
    public void keyboardEvent(boolean down, short keyCode) {
        NvConnection c = conn;
        if (c == null || state != State.CONNECTED) return;
        short keyMap = translator.translate(keyCode, -1);
        if (keyMap == 0) return;
        int flag;
        switch (keyCode) {
            case KeyEvent.KEYCODE_SHIFT_LEFT: case KeyEvent.KEYCODE_SHIFT_RIGHT: flag = KeyboardPacket.MODIFIER_SHIFT; break;
            case KeyEvent.KEYCODE_CTRL_LEFT: case KeyEvent.KEYCODE_CTRL_RIGHT: flag = KeyboardPacket.MODIFIER_CTRL; break;
            case KeyEvent.KEYCODE_ALT_LEFT: case KeyEvent.KEYCODE_ALT_RIGHT: flag = KeyboardPacket.MODIFIER_ALT; break;
            case KeyEvent.KEYCODE_META_LEFT: case KeyEvent.KEYCODE_META_RIGHT: flag = KeyboardPacket.MODIFIER_META; break;
            default: flag = 0;
        }
        if (flag != 0) modifiers = down ? (modifiers | flag) : (modifiers & ~flag);
        c.sendKeyboardInput(keyMap, down ? KeyboardPacket.KEY_DOWN : KeyboardPacket.KEY_UP,
                (byte) modifiers, (byte) 0);
    }

    @Override
    public void mouseButtonEvent(int buttonId, boolean down) {
        NvConnection c = conn;
        if (c == null || state != State.CONNECTED) return;
        byte b;
        switch (buttonId) {
            case 1: b = MouseButtonPacket.BUTTON_LEFT; break;
            case 2: b = MouseButtonPacket.BUTTON_MIDDLE; break;
            case 3: b = MouseButtonPacket.BUTTON_RIGHT; break;
            case 4: b = MouseButtonPacket.BUTTON_X1; break;
            case 5: b = MouseButtonPacket.BUTTON_X2; break;
            default: return;
        }
        if (down) c.sendMouseButtonDown(b); else c.sendMouseButtonUp(b);
    }

    @Override
    public void mouseMove(int dx, int dy) {
        NvConnection c = conn;
        if (c == null || state != State.CONNECTED) return;
        c.sendMouseMove((short) dx, (short) dy);
    }

    @Override
    public void mouseHighResScroll(boolean up) {
        NvConnection c = conn;
        if (c == null || state != State.CONNECTED) return;
        int amount = PreferenceConfiguration.readPreferences(appCtx).mouseSCAmount;
        if (amount <= 0) amount = 1;
        c.sendMouseHighResScroll((short) (up ? amount * 50 : -50 * amount));
    }

    @Override public void toggleSoftKeyboard() { special(7); }

    @Override
    public void special(final int value) {
        final SpecialListener l = specialHandler;
        if (l == null) return;
        main.post(new Runnable() { @Override public void run() { l.onSpecial(value); } });
    }

    // ---- stub renderers ----------------------------------------------------------------------

    private static final AudioRenderer STUB_AUDIO = new AudioRenderer() {
        @Override public int setup(MoonBridge.AudioConfiguration cfg, int rate, int samples) { return 0; }
        @Override public void start() {}
        @Override public void stop() {}
        @Override public void playDecodedAudio(short[] audioData) {}
        @Override public void cleanup() {}
    };

    private static final VideoDecoderRenderer STUB_VIDEO = new VideoDecoderRenderer() {
        @Override public int setup(int format, int width, int height, int redrawRate) { return 0; }
        @Override public void start() {}
        @Override public void stop() {}
        @Override public int submitDecodeUnit(byte[] data, int length, int type, int frameNumber, int frameType,
                                              char hostProcessingLatency, long receiveTimeMs, long enqueueTimeMs) {
            return MoonBridge.DR_OK;
        }
        @Override public void cleanup() {}
        @Override public int getCapabilities() { return 0; }
        @Override public void setHdrMode(boolean enabled, byte[] hdrMetadata) {}
    };
}
