Moonlight Axixi -> English (default) + Persian (fa)

apply.py rewrites a checkout of Axixi2233/moonlight-android:
  - resources: default (values) becomes English, values-fa gets Persian,
    values-zh-rCN / values-zh-rTW keep the original Chinese
  - hard-coded Chinese in layouts/preferences -> @string/ax_xxxx resources
  - hard-coded Chinese in Java -> com.limelight.utils.Tr.t("...") (runtime lookup: en / fa / zh)
  - adds Persian to the in-app language list, enables RTL
Text that is not in zh.tsv / en_fa.tsv stays unchanged, so newer upstream versions still build.

Run:  python3 apply.py <path-to-moonlight-android>

Step 2 (new): python3 apply_extra.py <path-to-moonlight-android>
  fixes "待触发" status texts, default-layout names from assets/config/*.json (摇杆, 十字键, 触控板 ...) and the
  extension-keyboard accessibility texts. Extra rows live in extra.tsv (zh <TAB> en <TAB> fa).

Step 3 (new): python3 apply_bubble.py <path-to-moonlight-android>
  floating bubble over other apps using Axixi's own controls (see header of apply_bubble.py).
  Order: apply.py -> apply_extra.py -> apply_bubble.py.  A second launcher icon "Axixi Bubble" opens the setup screen.
