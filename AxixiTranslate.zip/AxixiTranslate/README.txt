Moonlight Axixi -> English (default) + Persian (fa)

apply.py rewrites a checkout of Axixi2233/moonlight-android:
  - resources: default (values) becomes English, values-fa gets Persian,
    values-zh-rCN / values-zh-rTW keep the original Chinese
  - hard-coded Chinese in layouts/preferences -> @string/ax_xxxx resources
  - hard-coded Chinese in Java -> com.limelight.utils.Tr.t("...") (runtime lookup: en / fa / zh)
  - adds Persian to the in-app language list, enables RTL
Text that is not in zh.tsv / en_fa.tsv stays unchanged, so newer upstream versions still build.

Run:  python3 apply.py <path-to-moonlight-android>
